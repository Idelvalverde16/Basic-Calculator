﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    //Numbering operations
    public enum Operacion
    {
        NoDefinida = 0,
        Suma = 1,
        Resta = 2,  
        Multiplicacion = 3,
        Division = 4
    }
    public partial class Form1 : Form
    {
        //Declaring values and operations
        private double valor1 = 0;
        private double valor2 = 0;
        Operacion operador = Operacion.NoDefinida;
        public Form1()
        {
            InitializeComponent();
        }

        //Closing the calculator
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        //Minimizing the size of the calculator
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        //Maximizing the size of the calculator
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        //Make the number's shown when their button is pressed
        private void LeerNumero(string numero)
        {
            if (txtboxResultado.Text == "0" && txtboxResultado.Text  != null)
            {
                txtboxResultado.Text = numero;
            }
            else
            {
                txtboxResultado.Text += numero;
            }
        }

        //Operations being executed
        private double EjecutarOperacion()
        {
            double resultado = 0;
            switch (operador)
            {
                case Operacion.Suma:
                    resultado = valor1 + valor2;
                    break;
                case Operacion.Resta:
                    resultado = valor1 - valor2;
                    break;
                case Operacion.Multiplicacion:
                    resultado = valor1 * valor2;
                    break;
                case Operacion.Division:
                    resultado = valor1 / valor2;
                    break;
            }

            return resultado;
        }

        //Show the proccess of the operation while it's on course with a label
        private void ObtenerValor(string operador)
        {
            valor1 = Convert.ToDouble(txtboxResultado.Text);
            lblHistorial.Text = txtboxResultado.Text + operador;
            txtboxResultado.Text = "0";
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            LeerNumero("0");
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            LeerNumero("1");
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            LeerNumero("2");
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            LeerNumero("3");
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            LeerNumero("4");
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            LeerNumero("5");
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            LeerNumero("6");
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            LeerNumero("7");
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            LeerNumero("8");
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            LeerNumero("9");
        }

        //Adding
        private void btnSuma_Click(object sender, EventArgs e)
        {
            operador = Operacion.Suma;
            ObtenerValor("+");

        }

        //Result
        private void btnIgual_Click(object sender, EventArgs e)
        {
            if (valor2 == 0)
            {
                valor2 = Convert.ToDouble(txtboxResultado.Text);
                lblHistorial.Text += valor2 + "=";
                double resultado = EjecutarOperacion();
                valor1 = 0;
                valor2 = 0;
                txtboxResultado.Text = Convert.ToString(resultado);
            }
        }

        //Substracting
        private void btnResta_Click(object sender, EventArgs e)
        {
            operador = Operacion.Resta;
            ObtenerValor("-");
        }

        //Multiplicating
        private void btnMultiplicacion_Click(object sender, EventArgs e)
        {
            operador = Operacion.Multiplicacion;
            ObtenerValor("*");
        }

        //Dividing 
        private void btnDivision_Click(object sender, EventArgs e)
        {
            operador = Operacion.Division;
            ObtenerValor("/");
        }

        //Clear Results textbox
        private void btnC_Click(object sender, EventArgs e)
        {
            txtboxResultado.Clear();
        }

        //Decimals, etc
        private void btnPunto_Click(object sender, EventArgs e)
        {
            if (txtboxResultado.Text.Contains("."))
            {
                return;
            }
            txtboxResultado.Text += ".";
        }
    }
}
